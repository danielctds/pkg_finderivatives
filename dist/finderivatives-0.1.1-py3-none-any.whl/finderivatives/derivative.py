

import pandas as pd



class Derivative():
    
    def __init__(self, strike, maturity):
        self._strike = strike
        self._maturity = maturity
        


if __name__ == '__main__':
    print(' Ejecucion directa ...')
