
from finderivatives import Call
from finderivatives import Put
from finderivatives import Portfolio


#%% Covered Call


#%% Reverse Covered Call



#%% Protective Put



#%% Revers Protective Put



#%% Bull Spread

class BullSpread(Portfolio):
    
    def __init__(self, *derivatives):
        super().__init__(*derivatives)


#%% Bear Spread

class BearSpread(Portfolio):
    
    def __init__(self, *derivatives):
        super().__init__(*derivatives)


#%% Butterfly

class ButterflySpread(Portfolio):
    
    def __init__(self, *derivatives):
        super().__init__(*derivatives)


#%% Straddle

class StraddleSpread(Portfolio):
    
    def __init__(self, *derivatives):
        super().__init__(*derivatives)


#%% Strip

class StripSpread(Portfolio):
    
    def __init__(self, *derivatives):
        super().__init__(*derivatives)


#%% Strap

class StrapSpread(Portfolio):
    
    def __init__(self, *derivatives):
        super().__init__(*derivatives)


#%% Strangle

class StrangleSpread(Portfolio):
    
    def __init__(self, *derivatives):
        super().__init__(*derivatives)


#%%



#%%


