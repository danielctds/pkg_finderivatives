.. finderivatives documentation master file, created by
   sphinx-quickstart on Tue Aug 29 16:38:54 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to finderivatives's documentation!
==========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


Hola Mundo
==========

.. automodule:: finderivatives.european_call
   :members:

.. automodule:: finderivatives.european_put
   :members: